# Telegram Analiz Botu
Bu bot, Telegram üzerinden PDF dosyası alıp OpenAI GPT-4 kullanarak soruları cevaplar.