# Gelişmiş Telegram Analiz Botu
Bu bot, adminlerin yüklediği içeriklere göre kullanıcılardan gelen soruları GPT-4 ile yanıtlar.